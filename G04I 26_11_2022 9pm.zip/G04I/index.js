const express = require('express')
const app = express()
const puerto = 3000
const db = require ('./config/db')
const cors = require ('cors')
const multer = require ('multer')

//probando el controlador
//const items = require ('./controllers/itemsCtrlPRUEBA')
//console.log(items.itemsListar())

//generos controlador
//const generos = require ('./controllers/generosCtrl')

//generos.generoListar()


app.get('/',(req,res)=>{
    res.send("hola G04")   
})

//app.get('/about',(req,res)=>{
//    res.send("Pagina cerca de ...")   
//})

/////////rutas
//app.use('/api/items', require('./routes/itemsPRUEBA'))
app.use(express.json())
app.use(cors())
//imagen
app.use(express.static('public'))

app.use(express.urlencoded({extended:true}))
app.use('/about', require('./routes/paginas')) 
app.use('/api', require('./routes/api'))
app.use('/api/generos', require('./routes/generos'))
app.use('/api/items', require('./routes/items'))
app.use('/api/actores', require('./routes/actores'))
app.use('/api/usuarios', require('./routes/usuarios'))


app.listen(puerto, ()=>{
    console.log('Servidor activo, puerto: ' + puerto)
})

db()
