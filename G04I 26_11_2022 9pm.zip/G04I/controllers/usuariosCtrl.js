const usuarioModel = require ('../models/usuarioSchema')
const bcryptjs = require ('bcryptjs')

const usuarioGuarda = async (req,res) =>{
    console.log(req.body)
    
    try {
        const usuario = new usuarioModel(req.body)
        usuario.contrasena = await bcryptjs.hash(usuario.contrasena,10)
        await usuario.save()
        res.status(200).json({msj : "Usuario Creado"})
                
    } catch (err) {
        res.status(400).json({msj : "error en usuarioGuarda: " + err})
        
    }
}

const usuarioLogin = async (req,res) =>{
    console.log("intento de login")
    console.log(req.body)
    

    const {correo, contrasena} = req.body
    try {
        errores = false
        if(correo == ""){errores = true
            res.status(400).json({'msj':"Correo Incorrecto"})
        }
        if(contrasena == ""){errores = true
            res.status(400).json({'msj':"Contraseña Incorrecta"})
        }

        
        if(!errores){
            //validar
            //usar find en vez de findOne
            let usuario = await usuarioModel.find({ 'correo' : correo, 'contrasena' : contrasena})
            console.log(usuario)
            //res.send("accesando ...")
            if(usuario.correo=== ""){
                res.status(400).json({'msj' : "Datos de Acceso incorrectos"})
            }else{
                res.status(200).json({ 'msj ': "Datos de Acceso Validos"})
            }
            if(usuario.contrasena === ""){
                res.status(400).json({'msj' : "Datos de Acceso incorrectos"})
            }else{
                res.status(200).json({ 'msj ': "Datos de Acceso Validos"})
            }
            

        }
    } catch (err) { console.log("error usuarioLogin "+ err) }
}

module.exports={
    usuarioLogin,
    usuarioGuarda
}