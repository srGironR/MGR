const express = require ('express')
const router = express.Router()
const generosCtrl = require('../controllers/generosCtrl')

router.get('/', generosCtrl.generoListar)

module.exports = router