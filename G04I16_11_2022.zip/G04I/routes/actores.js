const express = require ('express')
const router = express.Router()
const actoresCtrl = require('../controllers/actoresCtrl')

router.get('/', actoresCtrl.actoresListar)

module.exports = router