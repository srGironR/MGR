const actoresModel = require ('../models/actoresSchema')


const actoresListar = async (req,res) => {
    let actores = await actoresModel.find()
    res.send(actores);
}
module.exports ={
    actoresListar
}