import { Pelicula } from "./Pelicula"

console.log("algo")
fetch("http://localhost:3000/api/items") 
.then (response => console.log(response.json()))
.catch(err => console.log("el error es: " + err))


export function ListaPeliculas(){
    return <>
        <div className='row my-2'>
                <div className='container'>
                    <div className='row align- center'>
                        <div className='col m-5'>
                            <Pelicula titulo="tiburon"
                            imagen = "https://www.lavanguardia.com/peliculas-series/images/movie/poster/1978/6/w1280/AlE6zdnlJV7zfrElwjmrEBvIMYf.jpg"
                            tipo = "Pelicula"
                            ano = "1978"
                            />                           
                        </div>
                    </div>
                </div>            
            </div>      
    </>
}
