
export function Pelicula(props){
        
    return <>
        <div className="col-3">
            <div className="card" >
                <img src={ props.imagen } class="card-img-top" alt="..."/>
                <div class="card-body">
                    <h3 class="card-title">{ props.titulo}</h3>                
                </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item">{ props.tipo }</li>
                <li class="list-group-item">Año: { props.ano }</li>
                <li class="list-group-item">Duracion: { props.duracion }</li>
            </ul>
            <div class="card-body">
                <a href="#" class="card-link">Ver</a>                
            </div>
            </div>

        </div>
    </>
}