import React from 'react'
import ReactDOM from 'react-dom/client'
import './css/bootstrap.min.css'

//import { Pelicula } from './Pelicula'
import { Header, Menu } from './components/Header'
import { ListaPeliculas } from './components/ListaPeliculas'



const root = ReactDOM.createRoot(document.getElementById('root'))
root.render( <div> 
            <Menu/>
            <Header/>
            <ListaPeliculas/>     
        </div>
    

    )