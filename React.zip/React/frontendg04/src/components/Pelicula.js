
export function Pelicula(props){
    
    const ano = 1978
    const genero = "Terror"
    const actores = [
        {nombre : "Roy Scheider"},
        {nombre : "Robert Sahw"}, 
        {nombre : "Richard Dreyfuss"}
    ]

    function reparto(actores){
        let text = ""
        actores.forEach(element => {
            text += element.nombre + ", "
        });
        return text
    }

    return <div>
        <h1>{ props.titulo }</h1>
        <h5>{ ano }</h5>
        <h5>{ genero }</h5>
        <h5>{ reparto(actores) }</h5>
        <h5>Duracion: { props.duracion}</h5>
    </div>
}