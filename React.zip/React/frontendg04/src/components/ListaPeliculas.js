import { Pelicula } from "./Pelicula"

export function ListaPelicula(){
    return <>
        <div className='row my-2'>
                <div className='container'>
                    <div className='row align- center'>
                        <div className='col m-5'>
                            <Pelicula/>
                        </div>
                    </div>
                </div>            
            </div>      
    </>
}
