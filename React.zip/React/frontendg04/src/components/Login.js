import Swal from 'sweetalert2'
import { useRef } from "react"

export function Login (){
    const correoRef = useRef()
    const contrasenaRef = useRef()
    const handleChange = (ev)=>{ console.log(ev.target.value) }
    const handleSubmit = (ev)=>{
        ev.preventDefault()
        console.log("enviado datos")
        const correo = correoRef.current.value
        console.log("correo... " + correo)
        const contrasena = contrasenaRef.current.value
        console.log("contraseña  " + contrasena)
        
        const usuario ={
            'correo': correo,
            'contrasena': contrasena
        }
        const options = {
            method : "POST",
            body : JSON.stringify(usuario)
        }
        
        fetch('http://localhost:3000/api/usuarios/login', options)
        .then(response => response.json())
        .then(data => { console.log(data) })
        .catch(err =>{console.log("error " + err)})



        /*if(correo === "admin@correo.com")
           // console.log("acceso concedido")
            Swal.fire({
                title: 'Acceso',
                text:"Acceso Concedido",
                icon: "success"
            })
        else
            //alert("Datos de Acceso Incorrectos")
            Swal.fire({
                title: 'Error!',
                text:"Datos de acceso Incorrectos ...",
                icon:'error'
            })*/
    }
    return <>
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-4 offset-4">
                    <form>
                        <div className="form-gropu">
                            <label for="exampleInputEmail1">
                                Email addres
                            </label>
                            <input type="email" ref={ correoRef } className="form-control" id="exampleInputEmail1" onClick={function(){console.log(' email click!!')}} onChange={ handleChange }></input>
                        </div>
                        <div className="form-group">
                            <label for="exampleInputPassword1">
                                Password
                            </label>
                            <input type="password" ref={ contrasenaRef }  className="form-control" id="exampleInputPassword1"></input>
                        </div>
                        <div className="form-group my-4">
                            <button type="button" className="btn btn-primary" onClick={handleSubmit}>
                                Acceder
                            </button>

                        </div>
                    </form>

                </div>

            </div>
        </div>    
    </>
}
