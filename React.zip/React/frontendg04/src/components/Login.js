export function Login (){
    return <>
        <div className="container-fluid">
            <div className="row">
                <div className="col-md-4 offset-4">
                    <form>
                        <div className="form-gropu">
                            <label for="exampleInputEmail1">
                                Email addres
                            </label>
                            <input type="email" className="form-control" id="exampleInputEmail1"></input>
                        </div>
                        <div className="form-group">
                            <label for="exampleInputPassword1">
                                Password
                            </label>
                            <input type="password" className="form-control" id="exampleInputPassword1"></input>
                        </div>
                        <div className="form-group my-4">
                            <button type="submit" className="btn btn-primary">
                                Acceder
                            </button>

                        </div>
                    </form>

                </div>

            </div>
        </div>    
    </>
}