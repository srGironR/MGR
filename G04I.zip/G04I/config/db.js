const mongoose = require ('mongoose')
const URIDB = "mongodb://0.0.0.0:27017/G04-EstoEsCine"

module.exports = () =>{
    const conn = () =>{
        mongoose.connect(
            URIDB,
            {
                keepAlive : true,
                useNewUrlParser: true,
                useUnifiedTopology: true
            },

            (err)=>{
                if(err){
                    console.log("Error conec: "+ err)
                }else{
                    console.log("Conexion Satisfactoria!")
                }
            }
        )
    }
    conn()
}

