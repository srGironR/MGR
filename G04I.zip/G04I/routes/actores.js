const express = require ('express')
const router = express.Router()
const actoresCtrl = require('../controllers/actoresCtrl')
const multer = require('multer')
const upload = multer({dest: "public/images/"})
const fs = require ('node:fs')

router.get('/', actoresCtrl.actoresListar)

//Guardar
router.post('/', actoresCtrl.actoresGuarda)

//actualizar
router.put('/', actoresCtrl.actoresActualizar)

//eliminar
router.delete('/:id', actoresCtrl.actoresEliminar)

router.put('/imagen/:id', upload.single('imagen'), async(req,res)=>{
    const imagen = req.file
    console.log("recibiendo imagen .. ")
    console.logo(imagen.mimetype)
    console.log("archivo subido como: " + imagen.filename)
    const id = req.params.id
    fs.rename('./public/images/' + imagen.filename, './public/images/' + 
    res.status(200).json({"msj" : "imagen Guardada"}))
}
)


module.exports = router