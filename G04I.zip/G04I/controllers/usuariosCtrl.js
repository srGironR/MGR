const usuarioModel = require ('../models/usuarioSchema')

const usuarioGuarda = async (req,rea) =>{
    console.log(req.body)
    res.send(". . .")
}

const usuarioLogin = async (req,res) =>{
    console.log("intento de login")
    console.log(req.body)
    

    const {correo, contrasena} = req.body
    try {
        errores = false
        if(correo ==""){errores = true
            res.status(400).json({"msj":"Correo Incorrecto"})
        }
        if(contrasena ==""){errores = true
            res.status(400).json({"msj":"Contraseña Incorrecta"})
        }

        
        if(!errores){
            //validar
            //
            let usuario = await usuarioModel.findOne({'correo' : correo, 'contrasena' : contrasena})
            console.log(usuario)
            //res.send("accesando ...")
            if(usuario.correo ==''){
                res.status(400).json({msj : "datos incorrectos"})
            }else{
                res.status(200).json({ msj : "OK"})
            }
            

        }
    } catch (err) { console.log("error usuarioLogin "+ err) }
}

module.exports={
    usuarioLogin,
    usuarioGuarda
}